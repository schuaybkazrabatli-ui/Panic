# PANIC! iOS – Brainrot Edition

Dieses Repository enthält das SwiftUI/WKWebView-iOS-Projekt und einen GitHub-Actions-Workflow.

## Build starten
1. Lade alle Dateien und Ordner dieses Pakets in das Wurzelverzeichnis des GitHub-Repositories hoch (nicht nur die ZIP-Datei).
2. Öffne den Tab **Actions**.
3. Wähle **Build PANIC iOS** und tippe **Run workflow** (oder pushe auf `main`).
4. Nach erfolgreichem Lauf liegt unter **Artifacts** das Artefakt `PANIC-unsigned-ipa`.

## Wichtig
Der Workflow baut eine **unsignierte** IPA als Build-Artefakt. Sie ist noch nicht direkt auf einem iPhone installierbar. Für eine installierbare IPA braucht es eine gültige Apple-Signierung und ein passendes Provisioning Profile. Niemals private Apple-Schlüssel oder Passwörter in den Quellcode schreiben.
