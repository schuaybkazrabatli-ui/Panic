import SwiftUI
@main struct PANICApp: App { var body: some Scene { WindowGroup { GameView().ignoresSafeArea().preferredColorScheme(.dark) } } }
