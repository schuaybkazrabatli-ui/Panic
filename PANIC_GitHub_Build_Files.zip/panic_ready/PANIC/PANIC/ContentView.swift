import SwiftUI
import WebKit
struct GameView: UIViewRepresentable {
 func makeUIView(context: Context) -> WKWebView {
  let w = WKWebView(frame: .zero); w.isOpaque = false; w.backgroundColor = UIColor(red: 8/255, green: 14/255, blue: 28/255, alpha: 1); w.scrollView.isScrollEnabled = false; w.scrollView.bounces = false
  if let u = Bundle.main.url(forResource: "index", withExtension: "html") { w.loadFileURL(u, allowingReadAccessTo: u.deletingLastPathComponent()) }; return w
 }
 func updateUIView(_ uiView: WKWebView, context: Context) {}
}
