# PANIC! 2.2 — iOS-Projekt

Dieses Xcode-Projekt verpackt die gespeicherte englische Brainrot-HTML-Version in eine iOS-App mit WKWebView. Die HTML-Datei ist lokal enthalten; kein Webserver wird benötigt.

## Auf dem iPhone installieren
1. Du brauchst einen Mac mit Xcode.
2. ZIP entpacken und `PANIC/PANIC.xcodeproj` in Xcode öffnen.
3. Projekt-Target `PANIC` → **Signing & Capabilities** → bei **Team** deine Apple-ID wählen. Falls nötig, Bundle Identifier auf einen eindeutigen Wert ändern.
4. iPhone per Kabel verbinden, entsperren und als Ziel auswählen.
5. **Run ▶** drücken. Eventuell muss auf dem iPhone der Entwicklermodus aktiviert werden.

## Wichtig
Das ist ein Xcode-Quellprojekt, keine bereits signierte IPA-Datei. Eine installierbare iOS-App muss auf macOS mit Xcode signiert und gebaut werden. Veröffentlichung im App Store erfordert Apples regulären Review- und Verteilungsprozess.
